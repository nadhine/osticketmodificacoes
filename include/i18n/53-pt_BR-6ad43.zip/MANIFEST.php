<?php return array (
  'Build-Date' => 'Fri, 13 Jan 17 17:13:36 +0000',
  'Phrases-Version' => '1.10',
  'Build-Version' => 'v1.10-6-gc0ab967',
  'Build-Major-Version' => '1.10',
  'Language' => 'pt_BR',
  'Id' => 'lang:pt_BR',
  'Last-Revision' => '2017-01-13 11:03-0500',
  'Version' => 148432,
);